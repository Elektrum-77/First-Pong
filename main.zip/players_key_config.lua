local config_key = 
{
  { -- player 1 key config
    up = "z",--default:z
    down = "s",--default:s
    speed = "a"--default:d
  },
  { -- player 2 key config
    up = "o",--default:o
    down = "l",--default:l
    speed = "i"--default:i
  }
}
return config_key